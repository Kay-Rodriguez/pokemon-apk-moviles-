import { Component, OnInit } from '@angular/core';
import { PokeApp } from 'src/app/services/poke-api';

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.page.html',
  styleUrls: ['./pokemon.page.scss'],
  standalone: false,
})
export class PokemonPage implements OnInit {
  pokemons: any[] = [];
  selectedPokemon: any = null;
  showDetails: boolean = false;
  searchTerm: string = '';
  isLoading: boolean = false;
  offset: number = 0;
  limit: number = 10;

  constructor(private pokeService: PokeApp) { }

  ngOnInit() {
    this.loadPokemons();
  }

  loadPokemons() {
    this.isLoading = true;
    this.pokeService.getPokemonList(this.limit, this.offset).subscribe(data => {
      this.pokemons = data;
      this.isLoading = false;
    }, error => {
      console.error('Error fetching Pokémon data', error);
      this.isLoading = false;
    });
  }

  nextPage() {
    this.offset += this.limit;
    this.loadPokemons();
  }

  prevPage() {
    if (this.offset >= this.limit) {
      this.offset -= this.limit;
      this.loadPokemons();
    }
  }

  searchPokemon() {
  if (!this.searchTerm.trim()) return;
  this.isLoading = true;
  this.pokeService.getPokemonByName(this.searchTerm).subscribe(data => {
    this.selectedPokemon = {
      name: data.name,
      image: data.sprites.front_default,
      full: data
    };
    this.showDetails = false;
    this.isLoading = false;
  }, error => {
    console.error('Pokémon no encontrado', error);
    this.selectedPokemon = null;
    this.isLoading = false;
  });

}
toggleDetails() {
  this.showDetails = !this.showDetails;
}

clearSearch() {
  this.selectedPokemon = null;
  this.searchTerm = '';
  this.loadPokemons();
}

showPokemonDetails(pokemon: any) {
  pokemon.showDetails = !pokemon.showDetails;
}


}
